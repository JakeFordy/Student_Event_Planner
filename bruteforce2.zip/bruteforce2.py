"""
Brute force algorithm

must generate all possible subsets and keep track of best solution (highest enjoyment)

returns in format:

========================================
EVENT PLANNER - RESULTS
========================================

Input File: input_small.txt
Available Time: 10 hours
Available Budget: £200

--- BRUTE FORCE ALGORITHM ---
Selected Activities:
- Game-Night (3 hours, £80, enjoyment 120)
- Pizza-Workshop (2 hours, £60, enjoyment 100)
- Hiking (5 hours, £30, enjoyment 140)

Total Enjoyment: 360
Total Time Used: 10 hours
Total Cost: £170

Execution Time: 0.002 seconds
"""


from time import perf_counter


INPUT_DIRECTORY = './inputs/'
INPUT_FILE = 'input_100.txt'


def read_from_file(filename: str):
    activities = []
    total_time = 0
    total_cost = 0

    with open(filename, 'r', encoding='utf-8') as f:
        f.readline()
        (total_time, total_cost) = f.readline().split(' ')
        for line in f:
            name, time, cost, enjoyment = line.strip().split()

            activities.append({
                "name": name,
                "time": int(time),
                "cost": int(cost),
                "enjoyment": int(enjoyment)                
                })

    return activities, int(total_time), int(total_cost)

def bruteforce(i, time_left, cost_left, current_selection, activities):
    #base - no more activities
    if i == len(activities):
        print('reached i')
        return 0, current_selection

    #2 routes: either skip this activity or take it
    #A: skip
    skip_enjoyment, skip_selection = bruteforce(i+1, time_left, cost_left, current_selection, activities)

    #B: Take (only if possible tho)
    if time_left >= activities[i]["time"] and cost_left >= activities[i]["cost"]:
        take_enjoyment, take_selection = bruteforce(i+1, time_left - activities[i]["time"], cost_left - activities[i]["cost"], current_selection + [activities[i]], activities)
        take_enjoyment += activities[i]["enjoyment"]

        #if better selection when taking this activity
        if take_enjoyment > skip_enjoyment:
            return take_enjoyment, take_selection

    #else if better selection when skipping this activity
    return skip_enjoyment, skip_selection


def print_solution(algorithm: str, enjoyment: int, solution: dict, exec_time):
    print('\n--- ', algorithm, ' ---')
    print('Selected Activities:')

    total_time = 0
    total_cost = 0

    for activity in solution:
        print(f'\t - {activity["name"]} ({activity["time"]} hours, £{activity["cost"]}, enjoyment {activity["enjoyment"]})')
        total_time += int(activity["time"])
        total_cost += int(activity["cost"])

    print('\nTotal Enjoyment:', enjoyment)
    print('Total Time Used:', total_time, 'hours')
    print(f'Total Cost: £{total_cost}')

    print('\nExecution Time:', exec_time, 'seconds')

def perform_algorithms():
    activities, time_budget, cost_budget = read_from_file(f'{INPUT_DIRECTORY}{INPUT_FILE}')

    bruteforce_start_time = perf_counter()
    bruteforce_enjoyment, bruteforce_solution = bruteforce(0, time_budget, cost_budget, [], activities)
    bruteforce_end_time = perf_counter()

    print('========================================')
    print('EVENT PLANNER - RESULTS')
    print('========================================\n')
    print('Input file:', INPUT_FILE)
    print('Available Time:', time_budget, 'hours')
    print(f'Available Budget: £{cost_budget}')

    print_solution('BRUTE FORCE ALGORITHM', bruteforce_enjoyment, bruteforce_solution, bruteforce_end_time - bruteforce_start_time)


if __name__ == '__main__':
    perform_algorithms()




#TODO:
#ORGANISE BRUTEFORCE FUNCTION HIERARCHY?
#--------- INPUT FROM TXT FILE
#DYNAMIC ALGO
#-----------GT EXECUTION TIMES
#MAYBE RESTRUCTURE BRUTEFORCE METHOD?? like return budget used etc so no need to recalculate
#and maybe call print from inside the bruteforce function to reduce redundancy in going through all algo solution loop at end again